package main

/**
 * Este arquivo é responsável por fazer o parser dos dados iniciais
 * Gerando html para os novos dados
 */

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strings"

	"tools/pkg"
)

// Separador do arquivo
const string_sep = ";"

// Número de palavras numa linha
const nword = 2

func main() {
	fileName := os.Args[1]
	log.Println("Opening the file ", fileName)

	//region Abre o arquivo
	file, err := os.Open(fileName)
	if err != nil {
		fmt.Println("cannot able to read the file", err)
		return
	}
	// põe na fila de destructors do escopo atual
	defer file.Close() //Do not forget to close the file
	//endregion

	//region Lendo o cabeçalho do arquivo
	fileStream := bufio.NewReader(file)
	_, err = fileStream.ReadBytes('\n')
	if err != nil {
		log.Panic(err)
	}
	// Caso queira exibir:
	// firstLine, err := fileStream.ReadBytes('\n')
	// buf := make([]byte, pkg.ChunkSize)
	// if err != io.EOF {
	// 	buf = append(buf, firstLine...)
	// }
	// header := strings.SplitN(string(buf), string_sep, nword)
	// log.Printf("%s -> %s", strings.ToUpper(header[0]), strings.ToUpper(header[1]))
	//endregion

	//region Andando sobre o restante do arquivo usando `chunks` de dados
	pkg.ProcessFile(*fileStream, func(s *string) {
		word := strings.SplitN(*s, string_sep, nword)
		log.Printf("%s -> %s", strings.ToUpper(word[0]), word[1])
	})
	//endregion
}
